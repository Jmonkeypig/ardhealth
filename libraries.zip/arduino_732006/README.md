<h1>CS5490</h1>

[![contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](https://github.com/tiagolobao/CS5490/issues)
[![GitHub](https://img.shields.io/github/license/mashape/apistatus.svg)](https://opensource.org/licenses/MIT)

Arduino Library / ESP for Communication with the Cirrus Logic CS5490 Chip

Please consider reading the [Wiki](https://github.com/tiagolobao/CS5490/wiki)

<h4> Other contributors </h4>

* Antônio Cezar de Castro Lima
* André Kuhn
* Vytautas Gabriunas
